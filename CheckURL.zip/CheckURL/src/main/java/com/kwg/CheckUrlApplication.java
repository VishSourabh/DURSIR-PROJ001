package com.kwg;

import java.io.IOException;
import java.net.MalformedURLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckUrlApplication {


	public static void main(String[] args) throws MalformedURLException, IOException,Exception {
		SpringApplication.run(CheckUrlApplication.class, args);

		
		Thread th=new Thread();
		th.start();
		th.sleep(1000000000);

	}
}
